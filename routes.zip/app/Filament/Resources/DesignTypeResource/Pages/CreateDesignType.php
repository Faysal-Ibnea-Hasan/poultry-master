<?php

namespace App\Filament\Resources\DesignTypeResource\Pages;

use App\Filament\Resources\DesignTypeResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDesignType extends CreateRecord
{
    protected static string $resource = DesignTypeResource::class;
}
