<?php

namespace App\Filament\Resources\OptionListResource\Pages;

use App\Filament\Resources\OptionListResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateOptionList extends CreateRecord
{
    protected static string $resource = OptionListResource::class;
}
