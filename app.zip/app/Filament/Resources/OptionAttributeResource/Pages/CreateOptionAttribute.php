<?php

namespace App\Filament\Resources\OptionAttributeResource\Pages;

use App\Filament\Resources\OptionAttributeResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateOptionAttribute extends CreateRecord
{
    protected static string $resource = OptionAttributeResource::class;
}
