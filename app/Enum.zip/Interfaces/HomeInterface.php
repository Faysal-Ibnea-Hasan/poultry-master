<?php

namespace App\Interfaces;
interface HomeInterface
{
    public function getMenu();
    public function getCompanies();

}
