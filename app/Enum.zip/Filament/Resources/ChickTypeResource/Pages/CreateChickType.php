<?php

namespace App\Filament\Resources\ChickTypeResource\Pages;

use App\Filament\Resources\ChickTypeResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateChickType extends CreateRecord
{
    protected static string $resource = ChickTypeResource::class;
}
