<?php

namespace App\Filament\Resources\DeadChickenResource\Pages;

use App\Filament\Resources\DeadChickenResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDeadChicken extends CreateRecord
{
    protected static string $resource = DeadChickenResource::class;
}
