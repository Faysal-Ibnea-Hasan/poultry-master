<?php

namespace App\Filament\Resources\OptionResultResource\Pages;

use App\Filament\Resources\OptionResultResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateOptionResult extends CreateRecord
{
    protected static string $resource = OptionResultResource::class;
}
